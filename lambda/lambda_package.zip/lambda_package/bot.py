import os
import random
import time
import datetime
import requests

# Configuration from Lambda environment variables
TOKEN = os.environ['DISCORD_TOKEN']
CHANNEL_ID = os.environ['CHANNEL_ID']
VARIANCE_SECONDS = 300  # �5 minutes (300 seconds) total variance

# Message variations for each scheduled announcement
message_variations = {
    "guildBank": [
        "Did you know we have a Guild Bank with tons of items available to request? Alts welcome! Check Discord for instructions.",
        "Our Guild Bank has plenty of items for all members! Alts are welcome too. See Discord for how to access.",
        "Need items? Check out our Guild Bank! We welcome requests from mains and alts. Instructions on Discord.",
        "Don't forget about our Guild Bank - loaded with items for everyone including alts! Details on Discord.",
        "Guild Bank reminder: we have TONS of items available for you and your alts! See Discord for request instructions."
    ],
    "bankLocations": [
        "Send items to: DNTBank (Time Loot), DNTSpells (60+ Any), DNTEpics (Epic Items), DNTCraft (EP Mold: PLATE ONLY, Ornate BP/Legs/Gloves only) and high-end crafting mats.",
        "Guild Bank locations: DNTBank for Time Loot, DNTSpells for 60+ spells, DNTEpics for Epic Items, and DNTCraft for EP Mold (PLATE ONLY) & Ornate BP/Legs/Gloves.",
        "Our bank characters: DNTBank (Time Loot), DNTSpells (Lvl 60+ spells), DNTEpics (Epic Items), DNTCraft (Plate EP Molds & Ornate BP/Legs/Gloves, high-end mats).",
        "Bank alts for your donations: DNTBank, DNTSpells, DNTEpics, and DNTCraft. See Discord for what goes where!",
        "Remember our bank alts: DNTBank, DNTSpells, DNTEpics, and DNTCraft. Check Discord for specific deposit guidelines."
    ],
    "website": [
        "Our Guild Bank website is updated daily with tons of new stuff constantly being added: https://thj-dnt.web.app/bank",
        "Check out our Guild Bank website - updated DAILY with new items: https://thj-dnt.web.app/bank",
        "Browse our Guild Bank inventory at https://thj-dnt.web.app/bank - we add new items every day!",
        "Visit our Guild Bank website for the latest inventory: https://thj-dnt.web.app/bank (updated daily)",
        "Need something? Our Guild Bank website shows all available items and is refreshed daily: https://thj-dnt.web.app/bank"
    ],
    "requestProcess": [
        "To request items, make a post in Discord under Requests. Don't be shy - we have tons of stuff, get greedy!",
        "Want something from the Guild Bank? Post in the Discord Requests channel. We have plenty, so don't hold back!",
        "Item requests go in the Discord Requests channel. We have an abundance of items, so feel free to ask for what you need!",
        "Need something? Post in Discord Requests! We have loads of items and want to help gear you up!",
        "For Guild Bank requests, post in our Discord Requests channel. We encourage you to ask - we have TONS of items!"
    ],
    "guildNeeds": [
        "Check Discord Announcements and Getting Started for info (channel Guild-Wanted) to see what we might need.",
        "Want to contribute? Check the Guild-Wanted channel in Discord to see our current needs.",
        "See what the guild is looking for in our Discord's Guild-Wanted channel (under Announcements and Getting Started).",
        "Help the guild grow! Check Discord Announcements and Getting Started sections for our Guild-Wanted list.",
        "Looking to donate? The Guild-Wanted channel in Discord shows what items we're currently seeking."
    ]
}

# Define which categories to use each hour (rotating pattern)
hourly_categories = [
    ['guildBank', 'bankLocations'],      # Hour 0, 5, 10, 15, 20
    ['website', 'requestProcess'],       # Hour 1, 6, 11, 16, 21
    ['guildNeeds', 'guildBank'],         # Hour 2, 7, 12, 17, 22
    ['bankLocations', 'website'],        # Hour 3, 8, 13, 18, 23
    ['requestProcess', 'guildNeeds'],    # Hour 4, 9, 14, 19
]

def get_random_message(category):
    """Get a random message from the specified category."""
    return random.choice(message_variations[category])

def simulate_typing(channel_id, duration=3):
    """Simulate typing in the channel with timeout."""
    typing_url = f"https://discord.com/api/v10/channels/{channel_id}/typing"
    try:
        response = requests.post(typing_url, headers={'Authorization': TOKEN}, timeout=2)
        if response.status_code != 204:
            print(f"Typing simulation warning: {response.status_code}")
    except Exception as e:
        print(f"Typing simulation error: {e}")
    time.sleep(duration)

def send_message(content):
    """Send message to Discord channel."""
    url = f"https://discord.com/api/v10/channels/{CHANNEL_ID}/messages"
    try:
        response = requests.post(
            url,
            headers={'Authorization': TOKEN, 'Content-Type': 'application/json'},
            json={'content': content},
            timeout=5
        )
        if response.status_code == 200:
            print(f"Message sent: {content[:50]}...")
        else:
            print(f"Message send error: {response.status_code}")
    except Exception as e:
        print(f"Message send failed: {e}")

def send_scheduled_messages():
    """Main message sending logic."""
    try:
        # Get current hour in UTC (adjust if needed)
        now = datetime.datetime.now()
        current_hour = now.hour
        
        # For non-UTC timezones, adjust with:
        # current_hour = (now.hour + TIMEZONE_OFFSET) % 24
        
        hour_index = current_hour % 5
        categories = hourly_categories[hour_index]
        
        print(f"Processing hour {current_hour} (index {hour_index}) with categories: {categories}")
        
        for category in categories:
            message = get_random_message(category)
            simulate_typing(CHANNEL_ID, duration=2)
            send_message(message)
            time.sleep(random.uniform(0.5, 1.5))
            
    except Exception as e:
        print(f"Error in message sending: {e}")
        raise

def lambda_handler(event, context):
    """AWS Lambda entry point."""
    try:
        # Add random delay for variance
        delay = random.randint(0, VARIANCE_SECONDS)
        print(f"Applying variance delay: {delay} seconds")
        time.sleep(delay)
        
        send_scheduled_messages()
        return {'statusCode': 200, 'body': 'Messages sent successfully'}
        
    except Exception as e:
        print(f"Lambda handler error: {e}")
        return {'statusCode': 500, 'body': 'Error processing messages'}